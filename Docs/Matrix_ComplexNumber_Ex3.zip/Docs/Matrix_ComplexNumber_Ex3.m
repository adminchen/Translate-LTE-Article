v1 = 1 + j;
v2 = -1 + j;
v3 = -1 - j;
v4 = 1 - j;

tv1 = 1/sqrt(2).*[1;1];
tv2 = 1/sqrt(2).*[1;-1];
tv3 = 1/sqrt(2).*[1;j];
tv4 = 1/sqrt(2).*[1;-j];

tv1_v1 = tv1 .* v1
tv2_v1 = tv2 .* v1
tv3_v1 = tv3 .* v1
tv4_v1 = tv4 .* v1

tv1_v2 = tv1 .* v2
tv2_v2 = tv2 .* v2
tv3_v2 = tv3 .* v2
tv4_v2 = tv4 .* v2

tv1_v3 = tv1 .* v3
tv2_v3 = tv2 .* v3
tv3_v3 = tv3 .* v3
tv4_v3 = tv4 .* v3

tv1_v4 = tv1 .* v4
tv2_v4 = tv2 .* v4
tv3_v4 = tv3 .* v4
tv4_v4 = tv4 .* v4


% sub plots for v1
subplot(4,5,1);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('A');   

subplot(4,5,2);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(tv1_v1), imag(tv1_v1),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv1 * v1');

subplot(4,5,3);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(tv2_v1), imag(tv2_v1),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv2 * v1');

subplot(4,5,4);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(tv3_v1), imag(tv3_v1),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv3 * v1');

subplot(4,5,5);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(tv4_v1), imag(tv4_v1),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv4 * v1');


% sub plots for v2
subplot(4,5,1+5);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('A');   

subplot(4,5,2+5);
plot(real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(tv1_v2), imag(tv1_v2),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv1 * v2');

subplot(4,5,3+5);
plot(real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(tv2_v2), imag(tv2_v2),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv2 * v2');

subplot(4,5,4+5);
plot(real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(tv3_v2), imag(tv3_v2),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv3 * v2');

subplot(4,5,5+5);
plot(real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(tv4_v2), imag(tv4_v2),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv4 * v2');


% sub plots for v3
subplot(4,5,1+5+5);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('A');   

subplot(4,5,2+5+5);
plot(real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(tv1_v3), imag(tv1_v3),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv1 * v3');

subplot(4,5,3+5+5);
plot(real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(tv2_v2), imag(tv2_v3),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv2 * v3');

subplot(4,5,4+5+5);
plot(real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(tv3_v3), imag(tv3_v3),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv3 * v3');

subplot(4,5,5+5+5);
plot(real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(tv4_v3), imag(tv4_v3),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv4 * v3');


% sub plots for v4
subplot(4,5,1+5+5+5);
plot(real(v1), imag(v1),'ro','MarkerFaceColor',[1 0 0], 'MarkerSize',10, ...
     real(v2), imag(v2),'go','MarkerFaceColor',[0 1 0], 'MarkerSize',10, ...
     real(v3), imag(v3),'bo','MarkerFaceColor',[0 0 1], 'MarkerSize',10, ...
     real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('A');   

subplot(4,5,2+5+5+5);
plot(real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10, ...
     real(tv1_v4), imag(tv1_v4),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv1 * v4');

subplot(4,5,3+5+5+5);
plot(real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10, ...
     real(tv2_v4), imag(tv2_v4),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv2 * v4');

subplot(4,5,4+5+5+5);
plot(real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10, ...
     real(tv3_v4), imag(tv3_v4),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv3 * v4');

subplot(4,5,5+5+5+5);
plot(real(v4), imag(v4),'yo','MarkerFaceColor',[1 1 0], 'MarkerSize',10, ...
     real(tv4_v4), imag(tv4_v4),'ko','MarkerFaceColor',[0 0 0], 'MarkerSize',10);
     axis([-1.5 1.5 -1.5 1.5]);
     title('B = tv4 * v4');

