%----------Input Section----------------
N=1000000;  %Number of samples to generate
variance = 0.5; % Variance of underlying Gaussian random variables
%---------------------------------------

%Independent Gaussian random variables with zero mean and unit variance
x = sqrt(variance)*randn(1, N);
y = sqrt(variance)*randn(1, N);
c = x + j*y;

%Rayleigh fading envelope with the desired variance
r = sqrt(variance)*abs(c);

step = 0.05;
range_n = -1.6:step:1.6;
range_r = 0:step:3;

hx = hist(x,range_n);
hx = hx/(step*sum(hx));

hy = hist(y,range_n);
hy = hy/(step*sum(hy));

hr = hist(r,range_r);
hr = hr/(step*sum(hr));

subplot(3,3,1);
plot(x,'b-');axis([0 200 -3 3]);

subplot(3,3,2);
plot(y,'b-');axis([0 200 -3 3]);

subplot(3,3,3);
plot(r,'r-');axis([0 200 -3 3]);

subplot(3,3,[4 7]);
plot(range_n,hx,'b-');xlim([-1.5 1.5]); ylim([0 2]);

subplot(3,3,[5 8]);
plot(range_n,hy,'b-');xlim([-1.5 1.5]); ylim([0 2]);

subplot(3,3,[6 9]);
plot(range_r,hr,'r-');ylim([0 2]);
